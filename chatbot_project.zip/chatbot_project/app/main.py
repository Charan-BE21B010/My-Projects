# app/main.py
from fastapi import FastAPI
from app.routers.chat import router as chat_router

app = FastAPI()

# Include the chat router
app.include_router(chat_router, prefix="/api")

@app.get("/")
def read_root():
    return {"message": "Welcome to the Chatbot API!"}