# app/models/message.py
from pydantic import BaseModel

class MessageRequest(BaseModel):
    user_input: str

class MessageResponse(BaseModel):
    bot_response: str