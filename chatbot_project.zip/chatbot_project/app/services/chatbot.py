# app/services/chatbot.py
from app.utils.nlp_utils import load_dataset, find_matching_response

# Path to the dataset
DATASET_PATH = "data/dataset.json"

# Load the dataset
dataset = load_dataset(DATASET_PATH)

def get_bot_response(user_input: str) -> str:
    """
    Get a response from the chatbot based on the dataset.
    """
    entry = find_matching_response(dataset, user_input)
    if entry:
        diagnosis = entry.get("Diagnosis", {})
        advice = entry.get("Advice", {})
        red_flags = entry.get("Red flag symptoms", [])
        
        response = f"Diagnosis: {diagnosis.get('title', 'N/A')}\n"
        response += f"Description: {diagnosis.get('description', 'N/A')}\n\n"
        response += f"Advice: {advice.get('title', 'N/A')}\n"
        response += f"Description: {advice.get('description', 'N/A')}\n\n"
        response += "Red Flag Symptoms:\n"
        for flag in red_flags:
            response += f"- {flag.get('description', 'N/A')}\n"
        return response
    return "I'm sorry, I couldn't find a matching response. Please try again."