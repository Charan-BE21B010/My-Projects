# app/utils/nlp_utils.py
import json
from pathlib import Path

def load_dataset(dataset_path: str):
    """
    Load the dataset from a JSON file.
    """
    try:
        with open(dataset_path, "r") as file:
            data = json.load(file)
        return data
    except Exception as e:
        print(f"Error loading dataset: {e}")
        return []

def preprocess_text(text: str) -> str:
    """
    Preprocess the input text (e.g., lowercasing, removing punctuation).
    """
    return text.lower().strip()

def find_matching_response(dataset, user_input: str):
    """
    Find a matching response in the dataset based on user input.
    """
    user_input = preprocess_text(user_input)
    for entry in dataset:
        for i in range(1, 11):  # Check all 10 questions
            question_key = f"Question{i}"
            answer_key = f"Answer{i}"
            if question_key in entry and answer_key in entry:
                question = preprocess_text(entry[question_key])
                if user_input in question:
                    return entry
    return None