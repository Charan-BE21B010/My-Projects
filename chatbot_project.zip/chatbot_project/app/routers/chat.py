# app/routers/chat.py
from fastapi import APIRouter
from app.models.message import MessageRequest, MessageResponse
from app.services.chatbot import get_bot_response

router = APIRouter()

@router.post("/chat", response_model=MessageResponse)
async def chat(message: MessageRequest):
    """
    Endpoint to interact with the chatbot.
    """
    bot_response = get_bot_response(message.user_input)
    return MessageResponse(bot_response=bot_response)