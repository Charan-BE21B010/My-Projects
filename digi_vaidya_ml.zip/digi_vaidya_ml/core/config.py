from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import List
import os
from typing import ClassVar

class Settings(BaseSettings):
    PROJECT_NAME: str = "Medical Diagnosis API"
    VERSION: str = "1.0.0"
    API_PREFIX: str = "/api"
    
    DATABASE_URL: str = "postgresql://postgres:1234567890@localhost:5434/kauvery"
    
    SECRET_KEY: str = "bWq8yF2sVAiklcKD0QaGgfdf77eXw5gW"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_DAYS: int = 30
    OTP_EXPIRE_MINUTES: int = 5
    
    CORS_ORIGINS: List[str] = ["*"]
    
    COUGH_DATA: str = "data/cough.csv"
    DIARRHEA_DATA: str = "data/diarrhea.csv"
    
    TWILIO_ACCOUNT_SID: str = "AC417ad96610b0a9558ced0044ad38f914"
    #test
    # TWILIO_AUTH_TOKEN: str = "c30f5b13200870437422d9cef52518bt"
    #prod
    TWILIO_AUTH_TOKEN: str = "c30f5b13200870437422d9cef52518bf"
    TWILIO_PHONE_NUMBER: str = "+14422540198"

    # Mark UPLOAD_FOLDER as a class variable
    UPLOAD_FOLDER: ClassVar[str] = os.path.join(os.getcwd(), 'uploads')

    class Config:
        case_sensitive = True

@lru_cache()
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
