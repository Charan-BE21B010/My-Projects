from pydantic import BaseModel, EmailStr, StringConstraints, Field
from typing import Optional, Dict, Any, List
from typing_extensions import Annotated
from datetime import datetime

from sqlalchemy import Column, Integer, String, Date, DateTime, Boolean, ForeignKey, LargeBinary
from sqlalchemy.orm import relationship 
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class UserResponse(BaseModel):
    id: int
    mobile_number: str
    name: str
    email: Optional[str]
    is_active: bool
    profile_picture: Optional[str]
    class Config:
        from_attributes = True

class OTPRequest(BaseModel):
    mobile_number: Annotated[str, StringConstraints(pattern=r'^\d{10}$')]

class OTPValidation(BaseModel):
    mobile_number: Annotated[str, StringConstraints(pattern=r'^\d{10}$')]
    otp: Annotated[str, StringConstraints(pattern=r'^\d{6}$')]

class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    expires_at: str
    user_exists: bool
    user_details: dict

class PredictRequest(BaseModel):
    answers: Dict[str, str] = {}

class FeedbackRequest(BaseModel):
    feedback: str

class LogsResponse(BaseModel):
    message: str
    records: List[Dict[str,Any]] = []

class ImageResponse(BaseModel):
    id: int
    user_id: int
    image_name: str
    upload_date: datetime

    class Config:
        from_attributes = True

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    dob = Column(Date)
    gender = Column(String)
    pin_code = Column(String)
    mobile_number = Column(String, unique=True)
    email = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, default=datetime.utcnow, nullable=True)
    is_active = Column(Boolean, default=True)

class UserRegistration(BaseModel):
    mobile_number: Annotated[str, StringConstraints(pattern=r'^\d{10}$')]
    name: Annotated[str, StringConstraints(min_length=2, max_length=50)]
    dob: str
    gender: Annotated[str, StringConstraints(pattern='^(male|female|other)$')]
    pin_code: Annotated[str, StringConstraints(pattern=r'^\d{6}$')]
    email: Optional[str] = None
    emergency_contact_number: Optional[str] = None
    emergency_contact_relationship: Optional[str] = None
    
class MPINRequest(BaseModel):
    mpin: str = Field(..., min_length=4, max_length=4)

class EmailVerifyResponse(BaseModel):
    message: str

class EmailValidation(BaseModel):
    otp: str

class update_user_details(BaseModel):
    name: Annotated[str, StringConstraints(min_length=2, max_length=50)]
    dob: str
    gender: Annotated[str, StringConstraints(pattern='^(male|female|other)$')]
    pin_code: Annotated[str, StringConstraints(pattern=r'^\d{6}$')]
    email: Optional[str]
    emergency_contact_number: Optional[str] = None
    emergency_contact_relationship: Optional[str] = None