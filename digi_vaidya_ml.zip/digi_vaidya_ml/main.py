from fastapi import FastAPI
from api.routes.user import auth
from api.routes.protocols.cough.decision_tree import cough
from api.routes.protocols.diarrhea.decision_tree import diarrhea
from api.routes.protocols.Backpain.decision_tree import backpain
from api.routes.protocols.Neckpain.decision_tree import Neckpain
from api.routes.protocols.earpain.decision_tree import earpain
from api.routes.protocols.fatigue.decision_tree import fatigue
from api.routes.protocols.swollen_glands.decision_tree import swollen_glands
from api.routes.Updated_template_protocols.earpain.decision_tree import updated_earpain
from api.routes.Updated_template_protocols.neckpain.decision_tree import updated_neckpain
from api.routes.Updated_template_protocols.diarrhea.decision_tree import updated_diarrhea
from api.routes.user import feedbacks
from api.routes.admin import get_logs
from db.database import Base, engine
from api.routes.user import user
app = FastAPI()

Base.metadata.create_all(bind=engine)

app.include_router(auth.router)
app.include_router(user.router)
app.include_router(cough.router)
app.include_router(backpain.router)
app.include_router(Neckpain.router)
app.include_router(diarrhea.router)
app.include_router(earpain.router)
app.include_router(fatigue.router)
app.include_router(swollen_glands.router)
app.include_router(feedbacks.router)
app.include_router(get_logs.router)
app.include_router(updated_earpain.router)
app.include_router(updated_neckpain.router)
app.include_router(updated_diarrhea.router)

@app.get("/")
def root():
    return {"message": "Welcome to the Digi Vaidya Backend Server"}
