from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager
from core.config import settings
import logging
from sqlalchemy.sql import text
from sqlalchemy.orm import Session

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create database engine
engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)

# Create SessionLocal class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
# # Create database engine
# engine = create_engine(settings.DATABASE_URL)

# # Create SessionLocal class
# SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create Base class for declarative models
Base = declarative_base()

@contextmanager
def get_db():
    """Database session context manager"""
    db: Session = SessionLocal()  # Create a new session
    try:
        yield db  # Yield the session to be used in the route
        db.commit()  # Commit after the request finishes
        logger.info("Transaction committed successfully")
    except Exception as e:
        db.rollback()  # Rollback if an error occurs
        logger.error(f"Transaction rolled back due to error: {str(e)}")
        raise
    finally:
        db.close()  # Close the session when done

# Database Tables SQL
REQUIRED_TABLES = """

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    mobile_number VARCHAR(15) UNIQUE NOT NULL,
    name VARCHAR(50) NOT NULL,
    dob DATE NOT NULL,
    gender VARCHAR(10) NOT NULL,
    pin_code VARCHAR(6) NOT NULL,
    email VARCHAR(255),
    emergency_contact_number VARCHAR(15),
    emergency_contact_relationship VARCHAR(50),
    created_at TIMESTAMP NOT NULL,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    is_email_verified BOOLEAN DEFAULT FALSE
);


CREATE TABLE IF NOT EXISTS otp_store (
    id SERIAL PRIMARY KEY,
    mobile_number VARCHAR(15) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    is_valid BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (mobile_number) REFERENCES users(mobile_number)
);

CREATE TABLE IF NOT EXISTS email_otp_store(
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    is_valid BOOLEAN DEFAULT TRUE
    
);
create table if not exists result_table(
    result_id serial primary key,
    user_id int not null,
    diagnosis text,
    OTC text,
    advices text,
    precaution text,
    dietary_advice text,
    red_flags text,
    diagnosis_tests text,
    foreign key (user_id) references users(id)
);


create table if not exists qna_sessions(
    id serial primary key,
    qna_session_id Varchar(10) not null,
    q_id Varchar(10) not null,
    user_id int not null,
    question text,
    subtitle text,
    answer text,
    created_at Timestamp not null,
    foreign key (user_id) references users(id)
);


create table if not exists prediction_logs(
    id serial primary key,
    user_id int not null,
    protocol varchar(20),
    qna_session_id Varchar(10) not null,
    result_id int not null,
    created_at Timestamp not null,
    foreign key (user_id) references users(id),
    foreign key (result_id) references result_table(result_id)
);

CREATE TABLE if not exists feedbacks (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL,
    feedback VARCHAR(1000) NOT NULL,
    created_at TIMESTAMP NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

Create table if not exists users_mpin(
    id serial primary key,
    user_id int not null,
    mpin Varchar(4) not null,
    foreign key (user_id) references users(id)
);


-- Create indexes
CREATE INDEX IF NOT EXISTS idx_users_mobile ON users(mobile_number);
CREATE INDEX IF NOT EXISTS idx_otp_mobile_valid ON otp_store(mobile_number, is_valid);
CREATE INDEX IF NOT EXISTS idx_prediction_logs_user ON prediction_logs(user_id);

"""

def init_db():
    """Initialize database with required tables."""
    try:
        with get_db() as connection:
            connection.execute(text(REQUIRED_TABLES))
            logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {str(e)}")
        raise
init_db()