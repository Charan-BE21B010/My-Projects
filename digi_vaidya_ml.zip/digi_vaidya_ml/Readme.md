# DIGI VAIDYA

## Project Description
This project will utilize a rule-based diagnostic approach to assist users in identifying potential health conditions. The project's app will analyze common symptoms (e.g., fever, cough, headache, fatigue) and provide immediate analysis, including tailored medicine recommendations, advice, precautions, and red flags.

## Project Version
**0.1.0**


## Backend Framework
- **Python FastAPI**

### Database
- **PostgreSQL**

- **DB Name**: `my_db`
- **Sample Localhost DB URL**:  
  postgresql://{username}:{password}@localhost:5432/my_db

## Setup Instructions

### Prerequisites
- **Python**: 3.12.6
- **PostgreSQL**: 17.2

### Instructions to Run the Project

1. **Open the project folder** in your preferred editor (e.g., VS Code) and then open the command prompt in that folder.

2. **Create and Activate the Virtual Environment**:
   - Search for "create environment" in VS Code using:
     
     Ctrl + Shift + P
    
   - Activate the environment:
     
     .venv\Scripts\activate  # On Windows
     source .venv/bin/activate  # On macOS/Linux
     

3. **Install Dependencies**:
   Install the required libraries and packages from the `requirements.txt` file:
   
   pip install -r requirements.txt
4. **Run the Application**:
    Start server using uvicorn
    uvicorn main:app --reload

