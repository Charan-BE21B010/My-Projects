from contextlib import contextmanager
from sqlalchemy import create_engine, text
import logging
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import Security
from jose import JWTError, jwt
from sqlalchemy import create_engine, text
from fastapi import FastAPI, Depends, HTTPException, status, Request
import pandas as pd
from core.config import Settings
import json

from sqlalchemy.orm import Session
from fastapi import HTTPException
from models import schemas
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.exc import SQLAlchemyError
import os
from fastapi import HTTPException, UploadFile
from pathlib import Path
import psycopg2

Base=declarative_base()

security = HTTPBearer()

settings = Settings()
# Logging configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Database


def get_question_mapping(df):
    try:
        mapping = {}
        columns = df.columns.tolist()
        
        answer_columns = [col for col in columns if col.startswith('Answer')]
        max_questions = len(answer_columns)
        
        logger.debug(f"Found {max_questions} answer columns")
        
        # For each question number
        for i in range(1, max_questions + 1):
            answer_col = f'Answer{i}'
            subtitle_col = f'Subtitle{i}'
            
            # Skip if required columns don't exist
            if answer_col not in columns or subtitle_col not in columns:
                continue
                
            question_col = f'Question{i}'
            if question_col not in columns:
                for col in columns:
                    if col not in [answer_col, subtitle_col] and not any(c in col for c in ['Answer', 'Subtitle']):
                        if df[col].notna().any():  # Check if column has any non-NA values
                            first_value = df[col].iloc[0]
                            if pd.notna(first_value) and str(first_value).strip():
                                question_col = col
                                break
            
            if question_col in columns:
                mapping[i] = {
                    "question": question_col,
                    "subtitle": subtitle_col,
                    "answer": answer_col
                }
        
        if not mapping:
            raise ValueError("No valid question mappings found in dataset")
            
        return mapping
        
    except Exception as e:
        logger.error(f"Error creating question mapping: {str(e)}")
        raise
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    """Dependency to get current authenticated user"""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        
        if not payload:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials"
            )
        
        user_id = payload.get("sub")
        mobile_number = payload.get("mobile_number")
        
        if not user_id or not mobile_number:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token payload"
            )
            
        return {
            "user_id": user_id,
            "mobile_number": mobile_number
        }
        
    except JWTError as e:
        logger.error(f"JWT validation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials"
        )
def store_results(user_id,result,conn):
    query = text('Insert into result_table (user_id,diagnosis,otc,advices,precaution,dietary_advice,red_flags,diagnosis_tests) values(:user_id,:diagnosis,:otc,:advices,:precaution,:dietary_advice,:red_flags,:diagnosis_tests) returning result_id')
    output=conn.execute(query,{
        'user_id':user_id,
        'diagnosis': json.dumps(result.get('Diagnosis', None)),  # Convert list/dict to JSON string
        'otc': json.dumps(result.get('Over the counter medication', None)),
        'advices': json.dumps(result.get('Advice', None)),
        'precaution': json.dumps(result.get('Precaution', None)),
        'dietary_advice': json.dumps(result.get('Dietary Advice', None)),
        'red_flags': json.dumps(result.get('Red_flags', None)),
        'diagnosis_tests': json.dumps(result.get('Diagnosis Tests', None))
    })
    return output
def store_prediction_logs(user_id,conn,protocol_name,qna_session_id,result_id):
    query2 = text('Insert into prediction_logs (user_id,protocol,qna_session_id,result_id,created_at) Values(:user_id,:protocol,:qna_session_id,:result_id,Now())')
    conn.execute(query2,{
        "user_id":user_id,
        "protocol": protocol_name,
        "qna_session_id":qna_session_id,
        "result_id":result_id

    })

def store_qna(user_id,qna_session_id,conn,curr_q_num,mapping_q,answers,data):
    query=text("Insert into qna_sessions(qna_session_id,q_id,user_id,question,subtitle,answer,created_at) values(:qna_session_id,:q_id,:user_id,:question,:subtitle,:answer,NOW())")
    conn.execute(query,{
    'qna_session_id':qna_session_id ,
    'q_id': f"Q{curr_q_num}",
    'user_id': user_id,
    "question": str(data[mapping_q["question"]].iloc[0]),
    'subtitle': str(data[mapping_q["subtitle"]].iloc[0]),
    'answer': answers[f"Q{curr_q_num}"]
})
'''
def parse_diagnosis(text):
    """Parse diagnosis data"""
    if not text or text == '-':
        return None
    parts = text.split(';')
    diagnosis = {
        "no": parts[0].split(':')[1].strip(),
        "title": parts[1].split(':')[1].strip(),
        "description": parts[2].split(':')[1].strip()
    }
    return [diagnosis]

'''
def parse_diagnosis(text):
    """Parse diagnosis data"""
    if not text or text == '-':
        return None
    if pd.isna(text):
        return None
    
    diagnoses = []
    parts = text.split(';')
    current_diagnosis = {}
    
    for part in parts:
        if 'diagnosis.no' in part:
            if current_diagnosis:
                diagnoses.append(current_diagnosis)
            current_diagnosis = {}
            current_diagnosis['no'] = part.split(':')[1].strip()
        elif ':' in part:
            key = part.split('.')[1].split(':')[0].strip()
            value = part.split(':')[1].strip()
            current_diagnosis[key] = value
            
    if current_diagnosis:
        diagnoses.append(current_diagnosis)
    
    return diagnoses

 
def parse_otc(text):
    """Parse OTC medication data"""
    if not text or text == '-':
        return None
    if pd.isna(text):
        return None
    medications = []
    parts = text.split(';')
    current_med = {}
    for part in parts:
        if 'otc.no' in part:
            if current_med:
                medications.append(current_med)
            current_med = {}
            current_med['no'] = part.split(':')[1].strip()
        elif ':' in part:
            key = part.split('.')[1].split(':')[0].strip()
            value = part.split(':')[1].strip()
            current_med[key] = value
    if current_med:
        medications.append(current_med)
    return medications
 
def parse_advice(text):
    """Parse advice data"""
    if not text or text == '-':
        return None
    advices = []
    parts = text.split(';')
    current_advice = {}
    for part in parts:
        if 'advice.no' in part:
            if current_advice:
                advices.append(current_advice)
            current_advice = {}
            current_advice['no'] = part.split(':')[1].strip()
        elif ':' in part:
            key = part.split('.')[1].split(':')[0].strip()
            value = part.split(':')[1].strip()
            current_advice[key] = value
    if current_advice:
        advices.append(current_advice)
    return advices
 
def parse_red_flags(text):
    """Parse red flag symptoms"""
    if not text or text == '-':
        return None
    if pd.isna(text):
        return None
    red_flags = []
    parts = text.split(';')
    number = None
    for part in parts:
        if 'red_flag.no' in part:
            number = part.split(':')[1].strip()
        elif 'red_flag.description' in part and number:
            description = part.split(':')[1].strip()
            red_flags.append({
                "no": number,
                "description": description
            })
    return red_flags if red_flags else None

def parse_lab_test(text):
    """Parse lab tests"""
    if not text or text == '-':
        return None
    lab_test = []
    parts = text.split(';')
    number = None
    for part in parts:
        if 'lab_test.no' in part:
            number = part.split(':')[1].strip()
        elif 'lab_test.title' in part and number:
            title = part.split(':')[1].strip()
            lab_test.append({
                "no": number,
                "title": title
            })
    return lab_test if lab_test else None

def parse_dietary_advice(text):
    """Parse dietary advice data"""
    if not text or text == '-':
        return None
    advices = []
    parts = text.split(';')
    current_advice = {}
    for part in parts:
        if 'dietry_advice.no' in part:
            if current_advice:
                advices.append(current_advice)
            current_advice = {}
            current_advice['no'] = part.split(':')[1].strip()
        elif ':' in part:
            key = part.split('.')[1].split(':')[0].strip()
            value = part.split(':')[1].strip()
            current_advice[key] = value
    if current_advice:
        advices.append(current_advice)
    return advices

# Define upload directory
UPLOAD_DIR = Path("uploads/user-profile-picture")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)  # Ensure the directory exists

async def upload_image(user_id: int, file: UploadFile):
    """Uploads and saves the user's profile picture to the file system."""
    try:
        file_content = await file.read()
        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in [".jpg", ".jpeg", ".png"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Only .jpg, .jpeg, and .png files are allowed."
            )

        image_name = f"{user_id}{file_extension}"
        image_path = UPLOAD_DIR / image_name

        for ext in [".jpg", ".jpeg", ".png"]:
            existing_image = UPLOAD_DIR / f"{user_id}{ext}"
            if existing_image.exists():
                os.remove(existing_image)

        with open(image_path, "wb") as image_file:
            image_file.write(file_content)

        return {"message": "Image uploaded successfully", "path": str(image_path)}

    except Exception as e:
        logger.error(f"Error uploading image: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Image upload failed: {str(e)}"
        )
