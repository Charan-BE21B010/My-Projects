from fastapi import APIRouter, Depends, HTTPException, status
import pandas as pd
import logging
from sqlalchemy import text
from typing import Dict
from core.config import settings
from db.database import get_db
from models.schemas import PredictRequest
from api.routes.user.auth import get_current_user
from utils.helper import get_question_mapping, store_prediction_logs,store_qna,store_results
import uuid

from utils import helper

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/diarrhea", tags=["Diarrhea"])

try:
    data = pd.read_csv("api/routes/Updated_template_protocols/Diarrhea/Dataset/Diarrhea_18-01-2025.csv")
    data = data.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
except Exception as e:
    logger.error(f"Error loading diarrhea dataset: {e}")
    raise

protocol_name = 'Diarrhea'
qna_session_id = str(uuid.uuid4())[:10] 

@router.post("/new_template/predict")
async def predict_diarrhea(question_request: PredictRequest, current_user: dict = Depends(get_current_user)):
    try:
        answers = question_request.answers
 
        if not answers:
            first_question = {
                "qid": "Q1",
                "q_title": data.loc[0, "Question1"],
                "q_subtitle": data.loc[0, "Subtitle1"],
                "possible_answers": sorted(
                    str(x).strip()
                    for x in data[f"Answer1"].unique() 
                    if pd.notna(x) and str(x).strip()
                ),
                "is_final": False
            }
            return {key: value if isinstance(value, str) else value for key, value in first_question.items()}
 
        filtered_data = data.copy()
        for qid, answer in answers.items():
            q_num = qid.replace("Q", "")
            answer_col = f"Answer{q_num}"
            filtered_data = filtered_data[filtered_data[answer_col] == answer]
 
        if filtered_data.empty:
            return {"error": "No matching path found."}
 
        next_q_num = len(answers) + 1
        question_col = f"Question{next_q_num}"
        # In your predict endpoint:
        if question_col not in filtered_data.columns or pd.isna(filtered_data.iloc[0][question_col]):
            first_row = filtered_data.iloc[0]
            result = {"is_final": True}
            # Add each section only if it has data
            diagnosis = helper.parse_diagnosis(first_row['Diagnosis'])
            if diagnosis:
                result["diagnosis"] = diagnosis
            advice = helper.parse_advice(first_row['Advice'])

            if advice:
                result["advice"] = advice
            medications = helper.parse_otc(first_row['Over the counter medication'])

            if medications:
                result["otc_medication"] = medications

            lab_test = helper.parse_lab_test(first_row['Lab tests'])
            if lab_test:
                result["lab_test"] = lab_test

            dietary_advice = helper.parse_dietary_advice(first_row['Dietary Advice'])
            if dietary_advice:
                result["dietary_advice"] = dietary_advice

            red_flags = helper.parse_red_flags(first_row['Red flag symptoms'])
            if red_flags:
                result["red_flags"] = red_flags

            return result
        
        next_question = {
            "qid": f"Q{next_q_num}",
            "q_title": filtered_data.iloc[0][question_col],
            "q_subtitle": filtered_data.iloc[0][f"Subtitle{next_q_num}"],
            "possible_answers": sorted(
                x.strip()
                for x in filtered_data[f"Answer{next_q_num}"].dropna().unique() 
                if x.strip()
            ),
            "is_final": False
        }
 
        return {key: value if isinstance(value, str) else value 
                for key, value in next_question.items()}
 
    except Exception as e:
        logger.error(f"Error processing prediction request: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error processing request: {str(e)}")
    