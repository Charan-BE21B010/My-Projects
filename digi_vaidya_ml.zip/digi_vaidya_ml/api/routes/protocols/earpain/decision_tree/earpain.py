from fastapi import Depends, HTTPException, status
import logging
import uuid
from fastapi import Security,APIRouter
import pandas as pd
from models.schemas import PredictRequest
from utils.helper import get_current_user,get_question_mapping,store_prediction_logs,store_qna,store_results
from db.database import get_db

router = APIRouter(prefix='/ear-pain',tags=['Earpain'])

logger = logging.getLogger(__name__)

try:
    data = pd.read_csv("api/routes/protocols/earpain/dataset/earpain.csv")
    data = data.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
except Exception as e:
    logger.error(f"Error loading cough dataset: {e}")
    raise

protocol_name = 'Earpain'
qna_session_id = str(uuid.uuid4())[:10] 
@router.post("/predict")
async def predict_EarPain(question_request: PredictRequest, current_user: dict = Depends(get_current_user)):
    try:
        with get_db() as conn:
            user_id = current_user['user_id']
            question_mapping = get_question_mapping(data)
            logger.debug(f"Question mapping: {question_mapping}")
            
            answers = question_request.answers
            logger.debug(f"Processing answers: {answers}")

            if not answers:
                first_q = question_mapping[1]
                possible_answers = [
                    str(x).strip()
                    for x in data[first_q["answer"]].dropna().unique()
                    if pd.notna(x) and str(x).strip()
                ]             
                return {
                    "qid": "Q1",
                    "q_title": str(data[first_q["question"]].iloc[0]),  # Preserve original case
                    "q_subtitle": str(data[first_q["subtitle"]].iloc[0]),  # Preserve original case
                    "possible_answers": sorted(possible_answers),
                    "is_final": False
                }
            # Filter data based on previous answers
            filtered_data = data.copy()
            for q_id, answer in answers.items():
                q_num = int(q_id.replace('Q', ''))
                if q_num in question_mapping:
                    answer_col = question_mapping[q_num]["answer"]
                    # Exact string matching without case modification
                    filtered_data = filtered_data[
                        filtered_data[answer_col].fillna('').str.strip() == answer.strip()
                    ]
                    logger.debug(f"Filtered to {len(filtered_data)} rows after {q_id}")

            if filtered_data.empty:
                logger.warning("No matching path found")
                return {
                    "is_final": True,
                    "Diagnosis": ["Unable to determine"],
                    "Medication": ["Please consult a doctor"],
                    "Advice": ["Please seek medical attention for proper diagnosis"],
                }

            curr_q=len(answers)
            if curr_q !=0:
                mapping_q=question_mapping[curr_q]
                store_qna(user_id,qna_session_id,conn,curr_q,mapping_q,answers,filtered_data)

            # next question number
            next_q_num = len(answers) + 1

            # Check if we've reached the end
            if next_q_num not in question_mapping:

                result={
                    "is_final":True
                    }
                if str(filtered_data['Diagnosis'].iloc[0]) != '-':
                    for advice in str(filtered_data['Diagnosis'].iloc[0]).split('\n'):
                        result['Diagnosis'] = [advice.strip()]
                    
                if str(filtered_data['Advice'].iloc[0]) != '-':
                    result['Advice'] = [
                        advice.strip() 
                        for advice in str(filtered_data['Advice'].iloc[0]).split('\n')
                    ]
                if str(filtered_data['Over the counter medication'].iloc[0]) != '-':
                    result['Over the counter medication'] = [
                        advice.strip() 
                        for advice in str(filtered_data['Over the counter medication'].iloc[0]).split('\n') 
                    ]
                if str(filtered_data['Red flag symptoms'].iloc[0]) != '-':
                    result['Red flags'] = [
                        advice.strip() 
                        for advice in str(filtered_data['Red flag symptoms'].iloc[0]).split('\n') 
                    ]

                output=store_results(user_id,result,conn)
                result_id = output.fetchone()[0]

                store_prediction_logs(user_id,conn,protocol_name,qna_session_id,result_id)
                
                return result

            # next question details
            next_q = question_mapping[next_q_num]
            
            # possible answers for next question
            possible_answers = [
                str(x).strip()
                for x in filtered_data[next_q["answer"]].dropna().unique()
                if pd.notna(x) and str(x).strip()
            ]

            if not possible_answers:
                result={
                    "is_final":True
                    }
                if str(filtered_data['Diagnosis'].iloc[0]) != '-':
                    for advice in str(filtered_data['Diagnosis'].iloc[0]).split('\n'):
                        result['Diagnosis'] = [advice.strip()]
                    
                if str(filtered_data['Advice'].iloc[0]) != '-':
                    result['Advice'] = [
                        advice.strip() 
                        for advice in str(filtered_data['Advice'].iloc[0]).split('\n')
                    ]
                if str(filtered_data['Over the counter medication'].iloc[0]) != '-':
                    result['Over the counter medication'] = [
                        advice.strip() 
                        for advice in str(filtered_data['Over the counter medication'].iloc[0]).split('\n') 
                    ]
                if str(filtered_data['Red flag symptoms'].iloc[0]) != '-':
                    result['Red flags'] = [
                        advice.strip() 
                        for advice in str(filtered_data['Red flag symptoms'].iloc[0]).split('\n') 
                    ]
                output=store_results(user_id,result,conn)
                result_id = output.fetchone()[0]
                
                store_prediction_logs(user_id,conn,protocol_name,qna_session_id,result_id)
                
                return result
            
            return{
                "qid": f"Q{next_q_num}",
                "q_title": str(filtered_data[next_q["question"]].iloc[0]),
                "q_subtitle": str(filtered_data[next_q["subtitle"]].iloc[0]),
                "possible_answers": sorted(possible_answers),
                "is_final": False
            }
           

    except Exception as e:
        logger.error(f"Error processing prediction request: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing request: {str(e)}"
        )
        

        