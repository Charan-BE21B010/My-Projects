from fastapi import FastAPI, Depends, HTTPException, status, Request,APIRouter
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from datetime import datetime
from typing import Dict, Any
from jose import JWTError, jwt
from sqlalchemy import create_engine, text
import logging
import pandas as pd
import uuid
from utils.helper import get_current_user,get_question_mapping,store_results, store_prediction_logs, store_qna
from db.database import get_db
from models.schemas import PredictRequest

router = APIRouter(prefix="/neck-pain", tags=["Neckpain"])
logger = logging.getLogger(__name__)

try:
    data = pd.read_csv("api/routes/protocols/Neckpain/dataset/Neckpain.csv")
    data = data.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
except Exception as e:
    logger.error(f"Error loading cough dataset: {e}")
    raise


protocol_name = 'Neckpain'

qna_session_id = str(uuid.uuid4())[:10] 

@router.post("/predict")
async def predict_NeckPain(question_request: PredictRequest, current_user: dict = Depends(get_current_user)):
    try:
        with get_db() as conn:
            user_id = current_user.get('user_id')
            user_dob = conn.execute(text('select dob from users where id=:id'),{'id':user_id}).fetchone()[0]
            today = datetime.today()
            age = today.year - user_dob.year - ((today.month, today.day) < (user_dob.month, user_dob.day))

            # Check age condition
            if age < 15 or age > 60:
                query=text('Insert into result_table (user_id,advices) values(:user_id,:advices) returning result_id')
                output = conn.execute(query,{
                    'user_id':user_id,
                    'advices': "Consult a doctor for further evaluation and investigation"
                })
                result_id = output.fetchone()[0]
                store_prediction_logs(user_id,conn,protocol_name,qna_session_id,result_id)
                return {
                    "is_final": True,
                    "Advice": ["Consult a doctor for further evaluation and investigation"]
                }
            # Get dynamic question mapping
            question_mapping = get_question_mapping(data)
            logger.debug(f"Question mapping: {question_mapping}")
            
            # Normalize answers
            normalized_answers = {
                key: value.strip().lower() 
                for key, value in question_request.answers.items()
            }
            logger.debug(f"Normalized answers: {normalized_answers}")

            # Initial question (no answers yet)
            if not normalized_answers:
                first_q = question_mapping[1]
                # Get possible answers for first question
                possible_answers = [
                    str(x).strip().capitalize() 
                    for x in data[first_q["answer"]].dropna().unique()
                    if pd.notna(x) and str(x).strip()
                ]
                
                return {
                    "qid": "Q1",
                    "q_title": str(data[first_q["question"]].iloc[0]).capitalize(),
                    "q_subtitle": str(data[first_q["subtitle"]].iloc[0]).capitalize(),
                    "possible_answers": sorted(possible_answers),
                    "is_final": False
                }

            # Filter data based on previous answers
            filtered_data = data.copy()
            for q_id, answer in normalized_answers.items():
                q_num = int(q_id.replace('Q', ''))
                if q_num in question_mapping:
                    answer_col = question_mapping[q_num]["answer"]
                    # Convert to string and normalize for comparison
                    filtered_data = filtered_data[
                        filtered_data[answer_col].fillna('').str.strip().str.lower() == answer.lower()
                    ]
                    logger.debug(f"Filtered to {len(filtered_data)} rows after {q_id}")

            if filtered_data.empty:
                logger.warning("No matching path found")
                return {
                    "is_final": True,
                    "Diagnosis": ["Unable to determine"],
                    "Medication": ["Please consult a doctor"],
                    "Advice": ["Please seek medical attention for proper diagnosis"],
                }
            curr_q = len(normalized_answers)
            if curr_q != 0:
                mapping_q=question_mapping[curr_q]
                store_qna(user_id,qna_session_id,conn,curr_q,mapping_q,normalized_answers,filtered_data)

            # Determine next question number
            next_q_num = len(normalized_answers) + 1

            # Check if we've reached the end
            if next_q_num not in question_mapping:
                result = {
                "is_final": True,
                "Diagnosis": [str(filtered_data['Diagnosis'].iloc[0]).capitalize()],
                }
                result['Advice']=[advice.strip().capitalize() for advice in str(filtered_data['Advice'].iloc[0]).split('\n')]
                if str(filtered_data['Over the counter medication'].iloc[0]) != '-':
                    result["Over the Counter Medication"] = [str(filtered_data['Over the counter medication'].iloc[0]).capitalize()]
                output=store_results(user_id,result,conn)
                result_id = output.fetchone()[0]

                store_prediction_logs(user_id,conn,protocol_name,qna_session_id,result_id)
                return result

            # Get next question details
            next_q = question_mapping[next_q_num]
            
            # Get possible answers for next question
            possible_answers = [
                str(x).strip().capitalize()
                for x in filtered_data[next_q["answer"]].dropna().unique()
                if pd.notna(x) and str(x).strip()
            ]

            if not possible_answers:
                result = {
                "is_final": True,
                "Diagnosis": [str(filtered_data['Diagnosis'].iloc[0]).capitalize()],
                }
                result['Advice']=[advice.strip().capitalize() for advice in str(filtered_data['Advice'].iloc[0]).split('\n')]
                if str(filtered_data['Over the counter medication'].iloc[0]) != '-':
                    result["Over the Counter Medication"] = [str(filtered_data['Over the counter medication'].iloc[0]).capitalize()]

                output=store_results(user_id,result,conn)
                result_id = output.fetchone()[0]

                store_prediction_logs(user_id,conn,protocol_name,qna_session_id,result_id)
                return result

            return {
                "qid": f"Q{next_q_num}",
                "q_title": str(filtered_data[next_q["question"]].iloc[0]).capitalize(),
                "q_subtitle": str(filtered_data[next_q["subtitle"]].iloc[0]).capitalize(),
                "possible_answers": sorted(possible_answers),
                "is_final": False
            }

    except Exception as e:
            logger.error(f"Error processing prediction request: {str(e)}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error processing request: {str(e)}"
            )
