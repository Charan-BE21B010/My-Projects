from fastapi import APIRouter, Depends, HTTPException, status
import pandas as pd
import logging
from sqlalchemy import text
from typing import Dict
from core.config import settings
from db.database import get_db
from models.schemas import PredictRequest
from api.routes.user.auth import get_current_user
from utils.helper import get_question_mapping, store_prediction_logs,store_qna,store_results
import uuid

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/swollen-glands", tags=["Swollen Glands"])

try:
    data = pd.read_csv("api/routes/protocols/swollen_glands/dataset/swollen_glands.csv")
    data = data.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
except Exception as e:
    logger.error(f"Error loading diarrhea dataset: {e}")
    raise

protocol_name = 'Swollen Glands'
qna_session_id = str(uuid.uuid4())[:10] 

@router.post("/predict")
async def predict_swollen_glands(
    question_request: PredictRequest,
    current_user: dict = Depends(get_current_user)
):
    """Process diarrhea prediction request"""
    try:
        with get_db() as conn:
            user_id = current_user.get('user_id')
            question_mapping = get_question_mapping(data)
            answers = question_request.answers

            if not answers:
                first_q = question_mapping[1]
                possible_answers = [
                    str(x).strip()
                    for x in data[first_q["answer"]].dropna().unique()
                    if pd.notna(x) and str(x).strip()
                ]
                
                return {
                    "qid": "Q1",
                    "q_title": str(data[first_q["question"]].iloc[0]),
                    "q_subtitle": str(data[first_q["subtitle"]].iloc[0]),
                    "possible_answers": sorted(possible_answers),
                    "is_final": False
                }

            filtered_data = data.copy()
            for q_id, answer in answers.items():
                q_num = int(q_id.replace('Q', ''))
                if q_num in question_mapping:
                    answer_col = question_mapping[q_num]["answer"]
                    filtered_data = filtered_data[
                        filtered_data[answer_col].fillna('').str.strip() == answer.strip()
                    ]

            if filtered_data.empty:
                return {
                    "is_final": True,
                    "Diagnosis": ["Unable to determine"],
                    "Medication": ["Please consult a doctor"],
                    "Advice": ["Please seek medical attention for proper diagnosis"],
                }
            curr_q = len(answers)
            if curr_q != 0:
                mapping_q = question_mapping[curr_q]
                store_qna(user_id,qna_session_id,conn,curr_q,mapping_q,answers,filtered_data)

            next_q_num = len(answers) + 1

            if next_q_num not in question_mapping:
                result = {
                    "is_final": True
                }
                
                if str(filtered_data['Diagnosis'].iloc[0]) != '-':
                    result["Diagnosis"] = [str(filtered_data['Diagnosis'].iloc[0])]
                    
                if str(filtered_data['Advice'].iloc[0]) != '-':
                    result["Advice"] = [str(filtered_data['Advice'].iloc[0])]
                    
                if str(filtered_data['Over the counter medication'].iloc[0]) != '-':
                    result["Over the counter medication"] = [str(filtered_data['Over the counter medication'].iloc[0])]
                    
                if str(filtered_data['Red flag symptoms'].iloc[0]) != '-':
                    result["Red flags"] = [str(filtered_data['Red flag symptoms'].iloc[0])]
                    

                output=store_results(user_id,result,conn)
                result_id = output.fetchone()[0]

                store_prediction_logs(user_id,conn,protocol_name,qna_session_id,result_id)                     
                return result

            next_q = question_mapping[next_q_num]
            possible_answers = [
                str(x).strip()
                for x in filtered_data[next_q["answer"]].dropna().unique()
                if pd.notna(x) and str(x).strip()
            ]

            if not possible_answers:
                result = {
                    "is_final": True
                }
                
                if str(filtered_data['Diagnosis'].iloc[0]) != '-':
                    result["Diagnosis"] = [str(filtered_data['Diagnosis'].iloc[0])]
                    
                if str(filtered_data['Advice'].iloc[0]) != '-':
                    result["Advice"] = [str(filtered_data['Advice'].iloc[0])]
                    
                if str(filtered_data['Over the counter medication'].iloc[0]) != '-':
                    result["Over the counter medication"] = [str(filtered_data['Over the counter medication'].iloc[0])]
                    
                if str(filtered_data['Red flag symptoms'].iloc[0]) != '-':
                    result["Red flags"] = [str(filtered_data['Red flag symptoms'].iloc[0])]
                    

                output=store_results(user_id,result,conn)
                result_id = output.fetchone()[0]

                store_prediction_logs(user_id,conn,protocol_name,qna_session_id,result_id)   
                return result

            return {
                "qid": f"Q{next_q_num}",
                "q_title": str(filtered_data[next_q["question"]].iloc[0]),
                "q_subtitle": str(filtered_data[next_q["subtitle"]].iloc[0]),
                "possible_answers": sorted(possible_answers),
                "is_final": False
            }

    except Exception as e:
        logger.error(f"Error processing prediction request: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing request: {str(e)}"
        )