from fastapi import APIRouter, HTTPException, Header, Body, Depends
from sqlalchemy import text

from db.database import get_db
from utils.helper import get_current_user
from models.schemas import update_user_details
router = APIRouter(prefix="/user", tags=["User Details"])

@router.get("/fetch-user/")
def fetch_user(current_user: dict = Depends(get_current_user)):
    try:
        user_id = current_user.get('user_id')
        with get_db() as conn:
            user = conn.execute(text("SELECT * FROM users WHERE id = :id"), {'id':user_id}).fetchone()
            if not user:
                raise HTTPException(status_code=404, detail="User not found")
            else:
                return dict(user._mapping)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error occurred: {e}")

@router.put("/update-user/")
def update_user(user:update_user_details,current_user: dict = Depends(get_current_user)):
    try:
        user_id = current_user.get('user_id')
        with get_db() as conn:
            update_fields = {
                "id":user_id,
                "name": user.name,
                "dob": user.dob,
                "gender": user.gender,
                "pin_code": user.pin_code,
            }
            
            if user.email:
                update_fields["email"] = user.email
                conn.execute(text('update users set is_email_verified = False where id=:id'),{'id':user_id})
            
            if user.emergency_contact_number:
                update_fields["emergency_contact_number"] = user.emergency_contact_number

            if user.emergency_contact_relationship:
                update_fields["emergency_contact_relationship"] = user.emergency_contact_relationship

            
            field_updates = ", ".join(
                f"{field} = :{field}" 
                for field in update_fields.keys()
            )
            
            sql = f"""
                UPDATE users 
                SET {field_updates}
                WHERE id = :id
            """
            
            conn.execute(text(sql), update_fields)
            return {"message": "User details updated successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error occurred: {e}")