from fastapi import APIRouter,Depends,HTTPException
import datetime
from sqlalchemy import text
from db.database import get_db
from utils.helper import get_current_user
from models.schemas import FeedbackRequest

router = APIRouter(prefix="/user/feedback", tags=["Feedbacks"])

@router.post("/")
async def feedback(suggestion: FeedbackRequest, current_user: dict = Depends(get_current_user)):
    try:
        with get_db() as conn:
            user_id = current_user.get("user_id")
            if not user_id:
                raise HTTPException(status_code=404, detail="User not found in token")
            
            # Insert the feedback into the database 
            query = text(""" 
                INSERT INTO feedbacks (user_id, feedback, created_at)
                VALUES (:user_id,:feedback, NOW()) RETURNING id;
            """)
            feedback_id=conn.execute(query, {
                'user_id':user_id,
                'feedback': suggestion.feedback
            }).fetchone()[0] 
           

        return { "feedback_id":feedback_id,"message": "Feedback submitted successfully"}

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
 
