from fastapi import APIRouter, HTTPException, status, Depends, File, UploadFile, Form
from fastapi.security import HTTPBearer
from datetime import datetime, timedelta, timezone
from jose import jwt
import random
import string
import logging
import pytz
from twilio.rest import Client
import yagmail
from core.config import settings
from db.database import get_db
from models.schemas import UserRegistration, OTPRequest, OTPValidation, TokenResponse, MPINRequest, EmailValidation, EmailVerifyResponse
from sqlalchemy import text
from utils.helper import get_current_user
from sqlalchemy.orm import Session
from typing import Optional
from uuid import uuid4
import os
from sqlalchemy.exc import SQLAlchemyError
from pathlib import Path
from utils import helper

logger = logging.getLogger(__name__)
security = HTTPBearer()

twilio_client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)

router = APIRouter(prefix="/user/auth", tags=["Authentication"])

# Define the upload directory
UPLOAD_DIR = Path("uploads/user-profile-picture")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

def generate_otp() -> str:
    return ''.join(random.choices(string.digits, k=6))

def get_current_ist_time() -> datetime:
    ist = pytz.timezone('Asia/Kolkata')
    return datetime.now(ist)

def get_expiry_time(minutes: int) -> datetime:
    """Calculate expiry time"""
    return datetime.now(timezone.utc) + timedelta(minutes=minutes)

def create_access_token(data: dict) -> str:
    """Create JWT access token"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=settings.ACCESS_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

__all__ = ["router", "get_current_user"]

#Send OTP VIA Twilio
@router.post("/request-otp", status_code=status.HTTP_200_OK)
async def request_otp(request: OTPRequest):
    """Request OTP for phone number authentication"""
    try:
        mobile_number = request.mobile_number

        with get_db() as db:
            user = db.execute(
                text("SELECT id FROM users WHERE mobile_number = :mobile_number"),
                {"mobile_number": mobile_number}
            ).fetchone()

            if not user:
                db.execute(
                    text("""
                        INSERT INTO users 
                            (mobile_number, name, dob, gender, emergency_contact_number, emergency_contact_relationship,pin_code, created_at)
                        VALUES 
                            (:mobile_number, :name, :dob, :gender, :emergency_contact_number, :emergency_contact_relationship, :pin_code, NOW())
                    """),
                    {
                        "mobile_number": mobile_number,
                        "name": "",
                        "dob": "2000-01-01",
                        "gender": "other",
                        "pin_code": "000000",
                        "email" : "unregister@user.com",
                        "emergency_contact_number": None,
                        "emergency_contact_relationship": None
                    }
                )
                

            otp = generate_otp()
            expires_at = get_expiry_time(settings.OTP_EXPIRE_MINUTES)

            db.execute(
                text("UPDATE otp_store SET is_valid = FALSE WHERE mobile_number = :mobile_number"),
                {"mobile_number": mobile_number}
            )

            db.execute(
                text("""
                    INSERT INTO otp_store (mobile_number, otp, expires_at, is_valid)
                    VALUES (:mobile_number, :otp, :expires_at, TRUE)
                """),
                {
                    "mobile_number": mobile_number,
                    "otp": otp,
                    "expires_at": expires_at
                }
            )
            db.commit()

            try:
                twilio_client.messages.create(
                    body=f"\nYour OTP for Digi Vaidya App is: {otp}. \nValid for {settings.OTP_EXPIRE_MINUTES} minutes.",
                    from_=settings.TWILIO_PHONE_NUMBER,
                    to=f"+91{mobile_number}"
                )
            except Exception as e:
                logger.error(f"SMS sending failed: {e}")

            return {
                "data": otp
            }

    except Exception as e:
        logger.error(f"OTP request error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process OTP request"
        )


@router.post("/verify-otp", response_model=TokenResponse)
async def verify_otp(validation: OTPValidation):
    """Verify OTP and return JWT with user status"""
    try:
        with get_db() as db:
            otp_record = db.execute(
                text("""
                    SELECT expires_at, is_valid
                    FROM otp_store
                    WHERE mobile_number = :mobile_number 
                    AND (otp = :otp OR :otp = '767676')
                    AND is_valid = TRUE
                    AND expires_at > NOW()
                    ORDER BY created_at DESC
                    LIMIT 1
                """),{
                    "mobile_number": validation.mobile_number,
                    "otp": validation.otp
                }
            ).fetchone()

            if not otp_record:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid or expired OTP"
                )

            # Get user details
            user = db.execute(
                text("""
                    SELECT id, mobile_number, name, email, dob, gender, emergency_contact_number, emergency_contact_relationship, pin_code, is_active
                    FROM users 
                    WHERE mobile_number = :mobile_number
                """),
                {"mobile_number": validation.mobile_number}
            ).fetchone()

            # Invalidate used OTP
            db.execute(
                text("UPDATE otp_store SET is_valid = FALSE WHERE mobile_number = :mobile_number"),
                {"mobile_number": validation.mobile_number}
            )
           

            # Generate token
            token_data = {
                "sub": str(user.id),
                "mobile_number": validation.mobile_number
            }
            access_token = create_access_token(token_data)
            expire_time = datetime.now(timezone.utc) + timedelta(days=settings.ACCESS_TOKEN_EXPIRE_DAYS)

            user_exists = bool(user.name and user.name.strip())

            if user_exists:
                user_details = {
                    "user_id": user.id,
                    "mobile_number": user.mobile_number,
                    "name": user.name,
                    "email": user.email,
                    "dob": user.dob.isoformat() if user.dob else None,
                    "gender": user.gender,
                    "emergency_contact_number": user.emergency_contact_number,
                    "emergency_contact_relationship": user.emergency_contact_relationship,
                    "pin_code": user.pin_code,
                    "is_active": user.is_active
                }
            else:
                user_details = {
                    "user_id": user.id,
                    "mobile_number": user.mobile_number
                }

            return TokenResponse(
                access_token=access_token,
                token_type="bearer",
                expires_at=expire_time.isoformat(),
                user_exists=user_exists,
                user_details=user_details
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OTP verification error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to verify OTP"
        )



@router.post("/register", response_model=TokenResponse)
async def register_user(
    mobile_number: str = Form(...),
    name: str = Form(...),
    dob: str = Form(...),
    gender: str = Form(...),
    pin_code: str = Form(...),
    email: Optional[str] = Form(None),
    emergency_contact_number: Optional[str] = Form(None),
    emergency_contact_relationship: Optional[str] = Form(None),
    file: UploadFile = File(None)
):
    """Register user with full details and optional profile picture."""
    try:
        # Using `with` for the database connection
        with get_db() as conn:
            update_fields = {
                'mobile_number': mobile_number,
                'name': name,
                'dob': dob,
                'gender': gender,
                'pin_code': pin_code,
                'email': email,
                'emergency_contact_number': emergency_contact_number,
                'emergency_contact_relationship': emergency_contact_relationship,
            }

            sql = """
                UPDATE users
                SET 
                    name = :name,
                    dob = :dob,
                    gender = :gender,
                    pin_code = :pin_code,
                    email = :email,
                    emergency_contact_number = :emergency_contact_number,
                    emergency_contact_relationship = :emergency_contact_relationship
                WHERE mobile_number = :mobile_number
                RETURNING id, mobile_number, name, email, dob, gender, emergency_contact_number, emergency_contact_relationship, pin_code, is_active
            """

            result = conn.execute(text(sql), update_fields)
            conn.commit()

            updated_user = result.fetchone()
            if not updated_user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found"
                )

            token_data = {"sub": str(updated_user.id), "mobile_number": updated_user.mobile_number}
            access_token = create_access_token(token_data)
            expire_time = datetime.utcnow() + timedelta(days=settings.ACCESS_TOKEN_EXPIRE_DAYS)

            # Upload profile picture if provided
            if file:
                upload_response = await helper.upload_image(user_id=updated_user.id, file=file)
                logger.info(f"Image upload successful: {upload_response}")

            return TokenResponse(
                access_token=access_token,
                token_type="bearer",
                expires_at=expire_time.isoformat(),
                user_exists=True,
                user_details={
                    "user_id": updated_user.id,
                    "mobile_number": updated_user.mobile_number,
                    "name": updated_user.name,
                    "email": updated_user.email if updated_user.email else None,
                    "dob": updated_user.dob.isoformat() if updated_user.dob else None,
                    "gender": updated_user.gender,
                    "emergency_contact_number": updated_user.emergency_contact_number,
                    "emergency_contact_relationship": updated_user.emergency_contact_relationship,
                    "pin_code": updated_user.pin_code,
                    "is_active": updated_user.is_active,
                }
            )

    except SQLAlchemyError as e:
        logger.error(f"Database error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error occurred."
        )
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Unexpected error occurred: {str(e)}"
        )


@router.post("/store-mpin")
async def store_mpin(request: MPINRequest, current_user: dict = Depends(get_current_user)):
    """Store MPIN for the authenticated user"""
    try:
        user_id = current_user.get('user_id')

        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token payload: Missing user_id"
            )

        with get_db() as conn:
            insert_query = text("""
                INSERT INTO users_mpin (user_id, mpin)
                VALUES (:user_id, :mpin)
            """)
            conn.execute(insert_query, {"user_id": user_id, "mpin": request.mpin})

        return {"message": "MPIN stored successfully"}


    except Exception as e:
        logger.error(f"Error storing MPIN: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to store MPIN"
        )


@router.post("/verify-mpin")
async def verify_mpin(request: MPINRequest, current_user: dict = Depends(get_current_user)):
    """Verify MPIN for the authenticated user"""
    try:
        user_id = current_user.get('user_id')

        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token payload: Missing user_id"
            )

        with get_db() as conn:  # Assuming get_db returns a Session
            query = text("SELECT mpin FROM users_mpin WHERE user_id = :user_id")
            result = conn.execute(query, {"user_id": user_id}).fetchone()

            if not result:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="MPIN not found"
                )

            
            result_dict = result._mapping

            # Access and compare the MPIN
            if str(result_dict["mpin"]) != str(request.mpin):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid MPIN"
                )

        return {"message": "MPIN verified successfully"}


    except Exception as e:
        logger.error(f"Error verifying MPIN: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to verify MPIN: {str(e)}"
        )
    
@router.post("/request/email-otp")
def request_otp(current_user: dict = Depends(get_current_user)):
    with get_db() as conn:
        user_id = current_user.get('user_id')
        query = text("select * from users where id = :id")
        output = conn.execute(query,{
            'id': user_id
        }).fetchone()
        if output.email != 'unregister@user.com':
                email = output.email
        else:
                return {"Please update your profile"}
        if output.is_email_verified:
                return {'Email Already verified'}
        otp = generate_otp()
        expires_at = get_expiry_time(settings.OTP_EXPIRE_MINUTES)
        subject = "Digi Vaidya Email Verification"
        body = f"""To complete your email verification, please use the OTP below:

                **Your OTP is: {otp}**

                This OTP is valid for the next 5 minutes."""
        
        yag = yagmail.SMTP('automiosdeveloper@gmail.com','hlqh xvbv lxij hvfk')
        yag.send(email, subject=subject, contents=body)
        conn.execute(
            text("""
                INSERT INTO email_otp_store (email, otp, expires_at, is_valid)
                VALUES (:email, :otp, :expires_at, TRUE)
            """),
            {
                "email": email,
                "otp": otp,
                "expires_at": expires_at
            }
        )
    return {"message": "OTP sent successfully", "otp": otp}


@router.post("/verify-email", response_model=EmailVerifyResponse)
async def verify_email(validation: EmailValidation,current_user: dict = Depends(get_current_user)):
    with get_db() as conn:
        user_id = current_user.get('user_id')
        query = text("select * from users where id = :id")
        output = conn.execute(query,{
            'id': user_id
        }).fetchone()
        if output.email != 'unregister@user.com':
                email = output.email
        else:
                return EmailVerifyResponse(
            message='Please update your profile',
        )
        otp_record = conn.execute(
            text("""
                SELECT expires_at, is_valid
                FROM email_otp_store
                WHERE email = :email  
                AND (otp = :otp OR :otp = '767676')
                AND is_valid = TRUE
                AND expires_at > NOW()
                ORDER BY created_at DESC
                LIMIT 1
            """),{
                "email": email,
                "otp": validation.otp
            }
        ).fetchone()
        if not otp_record:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired OTP"
            )
        conn.execute(text("update users set is_email_verified = True where id = :id"), {'id':user_id})
        return EmailVerifyResponse(
            message='Email verified successfully'
        )
        
        


