from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from datetime import datetime
from typing import Dict,List,Any
from jose import JWTError, jwt
from sqlalchemy import create_engine, text
import logging
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import Security
import pandas as pd
from fastapi import APIRouter
from utils.helper import get_current_user
from db.database import get_db
from models.schemas import LogsResponse

router = APIRouter(prefix="/admin", tags=["Prediction Logs"])
logger = logging.getLogger(__name__)



@router.post("/prediction_logs")
async def get_prediction_logs(current_user: dict = Depends(get_current_user)):
    user_id = current_user.get('user_id')
    with get_db() as conn:
        query = text("SELECT * FROM prediction_logs WHERE user_id = :user_id")
        logs_query = conn.execute(query, {"user_id": user_id}).mappings().fetchall()
        records_list = []
        logs_list = [dict(row) for row in logs_query]
        for i in logs_list:
            dic = {}
            dic['Protocol']=i['protocol']  
            QNA = []
            qna_query = text("select question, subtitle, answer from qna_sessions where qna_session_id=:qna_session_id and user_id=:user_id")
            qna_result = conn.execute(qna_query, {
                "qna_session_id": i['qna_session_id'],
                "user_id": user_id
            }).mappings().fetchall()
            qna_result_list = [dict(row) for row in qna_result]
            for j in qna_result_list:
                QNA.append({'Question': j['question'], 'Subtitle': j['subtitle'], 'Answer': j['answer']})
            dic['QNA'] = QNA
            res_query = text('select diagnosis, otc, advices,precaution,dietary_advice,red_flags from result_table where result_id=:result_id')
            res_result = conn.execute(res_query, {
                "result_id": i['result_id']
            }).mappings().fetchall()
            res_result_list = [dict(row) for row in res_result]
            dic['Result'] = res_result_list[0] 
            dic['Timestamp'] = i['created_at']
            records_list.append(dic)
        return LogsResponse(
            message="Success",
            records=records_list
        )







