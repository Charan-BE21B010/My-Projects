import pytesseract
from PIL import Image
import io
import re

# Manually specify the tesseract path if needed
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Update this path if needed

# Function to extract text from the image
async def extract_text_from_image(file):
    try:
        image_bytes = await file.read()
        image = Image.open(io.BytesIO(image_bytes))
        
        # Perform OCR
        extracted_text = pytesseract.image_to_string(image)
        
        # Parse the extracted text to find specific fields
        medical_data = parse_medical_data(extracted_text)
        
        return medical_data
    except Exception as e:
        raise Exception(f"Failed to process image with OCR: {e}")

# Function to parse medical data from the OCR text
def parse_medical_data(text):
    # Regex patterns for the required fields (customize as needed)
    name_pattern = r"Name\s*[:\-]?\s*([A-Za-z\s]+)"
    age_pattern = r"Age\s*[:\-]?\s*(\d+)"
    height_pattern = r"Height\s*[:\-]?\s*(\d+(\.\d+)?)"
    weight_pattern = r"Weight\s*[:\-]?\s*(\d+(\.\d+)?)"
    bp_pattern = r"Blood\s*Pressure\s*[:\-]?\s*([\d/]+)"
    sugar_pattern = r"Sugar\s*[:\-]?\s*(\d+(\.\d+)?)"

    # Find the matching fields using regex
    name = re.search(name_pattern, text)
    age = re.search(age_pattern, text)
    height = re.search(height_pattern, text)
    weight = re.search(weight_pattern, text)
    blood_pressure = re.search(bp_pattern, text)
    sugar = re.search(sugar_pattern, text)

    # Create a dictionary to store the extracted data
    medical_data = {
        "name": name.group(1) if name else None,
        "age": int(age.group(1)) if age else None,
        "height": float(height.group(1)) if height else None,
        "weight": float(weight.group(1)) if weight else None,
        "blood_pressure": blood_pressure.group(1) if blood_pressure else None,
        "sugar": float(sugar.group(1)) if sugar else None,
    }

    return medical_data
