import pytesseract
from PIL import Image
import io

class OCRService:
    def __init__(self):
        # Set the path to the Tesseract executable
        pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

    def extract_data(self, file: bytes):
        # Convert the file bytes to an image
        image = Image.open(io.BytesIO(file))

        # Extract text using pytesseract
        text = pytesseract.image_to_string(image)

        # Process the extracted text and return
        return text
