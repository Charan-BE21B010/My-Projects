from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Column, Integer, String, Float

# Change this to your PostgreSQL connection URL
DATABASE_URL = "postgresql://postgres:1234567890@localhost:5434/cauvery"  # Modify this connection string

# Create an SQLAlchemy engine for PostgreSQL (no `check_same_thread` for PostgreSQL)
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for models
Base = declarative_base()

# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Define the MedicalRecord model
class MedicalRecord(Base):
    __tablename__ = "medical_records"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    age = Column(Integer)
    height = Column(Float)
    weight = Column(Float)
    blood_pressure = Column(String)
    sugar = Column(Float)

# Create the database tables
Base.metadata.create_all(bind=engine)
