from sqlalchemy import Column, Integer, String, Float, Date
from sqlalchemy.ext.declarative import declarative_base

# Define the base class for SQLAlchemy models
Base = declarative_base()

class MedicalRecord(Base):
    __tablename__ = 'medical_records'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=True)  # Allows null values for name
    age = Column(Integer, nullable=True)
    height = Column(Float, nullable=True)
    weight = Column(Float, nullable=True)
    blood_pressure = Column(String, nullable=True)
    sugar = Column(String, nullable=True)
    date_of_birth = Column(Date, nullable=True)
