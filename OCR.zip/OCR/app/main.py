from fastapi import FastAPI, File, UploadFile
from app.services.ocr_service import OCRService # Import the OCRService

app = FastAPI()

# Create an instance of OCRService
ocr_service = OCRService()


@app.post("/extract_and_save/")
async def extract_and_save(file: UploadFile = File(...)):
    # Read the file as bytes
    file_bytes = await file.read()

    # Extract text using OCR service
    extracted_data = ocr_service.extract_data(file_bytes)

    # Logic to save data into the database
    # Here you would process the extracted data and save it to your DB

    return {"extracted_data": extracted_data.split('\n')}
